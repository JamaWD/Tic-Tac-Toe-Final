var board = document.getElementsByClassName('board'),
    xTurn = true,
    claimed = new Array(8),
    x = 1,
    o = 2,
    xScore = 0,
    xScoreText = document.getElementById('xScore'),
    oScore = 0,
    oScoreText = document.getElementById('oScore'),
    winner,
    winnerText = document.getElementById('winnerText'),
    retry = document.getElementById('retry'),
    stillPlaying = true;









var person1 = {},
    person2 = {};

function initGame() {



    //check if users exist
    //if not call getUserInfo()
    if (person1.name === undefined && person2.name === undefined) {
        getUserInfo();
    } else {
        //starts game
        generateGameBoard();
    }




}


function getUserInfo() {
    // get Player X's Name
    person1.name = prompt("Please enter Player X's Name", "");
    if (person1 != null) {
        document.getElementById("initGame")
    }



    //get Player O's Name
    person2.name = prompt("Please enter Player O's Name", "");
    if (person2 != null) {
        if (person1.name !== person2.name) {
            document.getElementById("playerName").innerHTML =
                person1.name + '(X)' + " " + "VS" + " " + person2.name + '(O)'
        } else {
            alert("Error, Same name entered;");
        }
    }
}





// Checks if square is selected, Selects a square  
window.onload = function selectSquare() {
    for (i = 0; i < board.length; i++) {
        board[i].addEventListener('click', nextRound, false);
        board[i].id = i;
    }
    retry.addEventListener('click', resetGame);
}

function displayResults(player) {
    if (claimed[0] == player && claimed[1] == player && claimed[2] == player) {
        console.log(player + " wins. 0,1,2");
        winner = player;
        checkGameState();
    } else if (claimed[3] == player && claimed[4] == player && claimed[5] == player) {
        console.log(player + " wins. 3,4,5");
        winner = player;
        checkGameState();
    } else if (claimed[6] == player && claimed[7] == player && claimed[8] == player) {
        console.log(player + " wins. 6,7,8");
        winner = player;
        checkGameState();
    } else if (claimed[0] == player && claimed[3] == player && claimed[6] == player) {
        console.log(player + " wins. 0,3,6");
        winner = player;
        checkGameState();
        
    } else if (claimed[1] == player && claimed[4] == player && claimed[7] == player) {
        console.log(player + " wins. 1,4,7");
        winner = player;
        checkGameState();
    } else if (claimed[2] == player && claimed[5] == player && claimed[8] == player) {
        console.log(player + " wins. 2,5,8");
        winner = player;
        checkGameState();
    } else if (claimed[0] == player && claimed[4] == player && claimed[8] == player) {
        console.log(player + " wins. 0,4,8");
        winner = player;
        checkGameState();
    } else if (claimed[2] == player && claimed[4] == player && claimed[6] == player) {
        console.log(player + " wins. 2,4,6");
        winner = player;
        checkGameState();
    } else if (tieCheck()) {
        checkGameState();
    }

}


// checking to see the Game State
function checkGameState() {
    stillPlaying = false;
    retry.style.display = "block";
    if (winner == 1) {
        winnerText.innerHTML = "Player X Wins";
        xScore++;
        xScoreText.innerHTML = "X: " + xScore;
    } else if (winner == 2) {
        winnerText.innerHTML = "Player O Wins";
        oScore++;
        oScoreText.innerHTML = "O: " + oScore;
    } else if (winner == -1) {
        winnerText.innerHTML = "Tie Game";
    }
}

// Added another function to check if the Game Tied
function tieCheck() {
    for (i = 0; i < claimed.length; i++) {
        if (claimed[i] == undefined) {
            return false;
        }
    }
    winner = -1;
    return true;
}




// Changes current user 
function nextRound() {
    if (stillPlaying) {
        currentSquare = parseInt(this.id);
        if (xTurn && this.innerHTML == "") {
            this.innerHTML = "<h1 class='x'>x</h1>";
            xTurn = false;
            claimed[currentSquare] = 1;
            console.log("claimed " + currentSquare + " is " + claimed[currentSquare]);
            displayResults(x);
        } else if (this.innerHTML == "") {
            this.innerHTML = "<h1 class='o'>o</h1>";
            xTurn = true;
            claimed[currentSquare] = 2;
            console.log("claimed " + currentSquare + " is " + claimed[currentSquare]);
            displayResults(o);
        }
    }
}

// Clears all game data and brings back the welcome screen 
function resetGame() {
    console.log("retry button");
    for (i = 0; i < board.length; i++) {
        board[i].innerHTML = "";
        claimed[i] = undefined;
    }
    stillPlaying = true;
    winnerText.innerHTML = "";
    retry.style.display = "none";
}